package com.softprogram;
/*
 * 管理/管理模块*/
public class Admin {
	public void Checked_car(){}//审核发车
	public void Checked_post(){}//审核帖子
	public void Checked_comment(){}//审核评论
}
