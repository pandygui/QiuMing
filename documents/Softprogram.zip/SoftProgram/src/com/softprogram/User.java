package com.softprogram;
/*
 * 
 * 用户模块*/
public class User {
	private String userName;
	private String password;
	public User(){													//无参构造器
		
	} 
	public User(String userName,String password){                  //有参构造器
		this.userName=userName;
		this.password=password;
	}
	public String getuserName(){           //获取用户名
		return this.userName;
	}
	public String getpassword(){      //获取密码
		return this.password;
	}
	public void Register(){          //注册
		
	}
	public void login(){            //登录
		
	}            
	public void Modify_password(){ //修改密码
		
	}          
	public void Modify_userdate(){    //修改用户资料
		
	}       
}
