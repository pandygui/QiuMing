package com.softprogram;
/*
 * 发车模块*/
public class Start_post {
	public void Report_car(){}//举报发车
	public void Start_car(){}//发车
	public void Set_permiss(){}//设置上车权限
	public void Aboard(){}//上车
}
