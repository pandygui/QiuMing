package com.softprogram;
/*
 * 帖子模块*/
public class Post {
	public void Create_post(){}//创建帖子
	public void View_post(){}//查看帖子
	public void Modigy_post(){}//修改帖子
	public void Collection_post(){}//收藏帖子
	public void Setlable_post(){}//设置帖子标签
	public void Likelable_post(){}//赞同帖子标签
	public void Like_post(){}//点赞帖子
	public void Delete_post(){}//删除帖子
	public void Report_post(){}//举报帖子
}
