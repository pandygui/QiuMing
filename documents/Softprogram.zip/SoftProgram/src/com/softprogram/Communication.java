package com.softprogram;
/*
 * 社交模块*/
public class Communication{
	public void Focus(){}//关注
	public void Sent_message(){}//发送私信
	public void Search_user(){}//搜索用户
	public void Search_message(){}//搜索私信
	public void Search_license(){}//搜索车牌号
}
