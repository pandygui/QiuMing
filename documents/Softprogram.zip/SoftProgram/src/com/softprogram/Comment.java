package com.softprogram;
/*
 * 评论*/
public class Comment {
	public void Comment_post(){}//评论帖子
	public void View_Comment(){}//查看帖子评论
}
